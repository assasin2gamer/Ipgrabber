/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ipadresss;
import java.util.*;
import java.io.*;
import java.util.regex.*;
import java.io.IOException;
import java.nio.file.Files;
import java.util.stream.Collectors;
import javax.swing.JFileChooser;
import java.io.File;       

/**
 *
 * @author Stephen Chang
 */
public class Ipadresss {

    /**
     * @param args the command line arguments
     */
    
    
    private static ArrayList<String> adresses = new ArrayList<String>();
    private static ArrayList<String> adresses2 = new ArrayList<String>();
    private static ArrayList<String> adresses3 = new ArrayList<String>();
    private static ArrayList<String> lines = new ArrayList<String>();
    private static int x1 = 0;
    
    public static String adressmaker()
    {
        int repeat = 0;
        String reString = "";
        for (String yeet: lines)
        {
            String inp = yeet;
            //System.out.println("File inp string is "+inp);
            Pattern pattern = 
                Pattern.compile("^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)");
            Matcher match = pattern.matcher(inp);
            while(match.find()) {
                adresses.add(match.group());
            }
        }
        
        List<String> deduped = adresses.stream().distinct().collect(Collectors.toList());
        
        for(String yee: deduped)
        {
            reString = (reString + "\n"+ yee);
            System.out.println(yee);
            
        }
        
        for (String yeee: deduped)
        {
            repeat = 0; 
            for (String tee: adresses)
                {
                     if (yeee.equals(tee))   
                     {
                         repeat++;
                     }
                }
            reString = (reString + "\n"+ yeee + " came up: " + repeat);
            System.out.println(yeee + " came up: " + repeat);
            
        }
        
        
        return (reString);
    }

    public static void readline(String location)
    {
        String filePath = location;

        try {
            BufferedReader lineReader = new BufferedReader(new FileReader(filePath));
            String lineText = null;

            while ((lineText = lineReader.readLine()) != null) {
                lines.add(lineText);
            }

            lineReader.close();
        } catch (IOException ex) {
            System.err.println(ex);
        }
    }
    /*
    public static void findbiggestleast()
    {
        int numcount = 0;
        int countofadress = 0;
        int numcount2 = 0;
        for(String stuff: adresses)
        {
            for (String yep: adresses2)
            {
                if (stuff != yep)
                {
                    adresses2.add(yep);
                }
            }
        }
        for (String yeet: adresses2)
        {
            System.out.println(yeet);
            
        }
 
    }
    */
}
